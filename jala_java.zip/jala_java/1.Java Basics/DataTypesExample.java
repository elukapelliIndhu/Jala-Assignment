
public class DataTypesExample {

    public static void main(String[] args) {
// Integer Variable
        int age = 25;

// boolean variable
        boolean isJavaFun = true;

        // char variable
        char grade = 'a';

//float variable
        float height = 10.0f;

//double vaariable
        double pi = 3.14;

// print the variables
        System.out.println("Age: " + age);
        System.out.println("Is Java Fun? " + isJavaFun);
        System.out.println("Grade: " + grade);
        System.out.println("Height: " + height);
        System.out.println("Value of Pi: " + pi);
    }
}
