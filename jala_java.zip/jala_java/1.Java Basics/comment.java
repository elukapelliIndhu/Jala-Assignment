
public class comment {

    public static void main(String[] args) {

        // This is a single-line comment
        System.out.println("Hello, Java!");

        /*
         * This is a multi-line comment.
         * It can span across multiple lines.
         * Used for describing a block of code or logic.
         */
        int a = 5;
        int b = 10;
        int sum = a + b;

        System.out.println("Sum: " + sum);
    }
}
