
public class exchange {

    public static void main(String[] args) {
        // Replacing characters in strings

        String str5 = "character";
        String replaced = str5.replace('a', '@');

        System.out.println(" Replaced String: " + replaced);
    }
}
