
public class compare {

    public static void main(String[] args) {
        //  Comparing strings using equals()
        String str1 = "Hello";
        boolean eq = str1.equals("Hello");
        System.out.println("7. Equals 'Hello': " + eq);
    }
}
