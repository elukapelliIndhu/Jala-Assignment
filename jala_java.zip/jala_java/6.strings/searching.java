
public class searching {

    public static void main(String[] args) {
        String words = "Today is beautiful .";
        System.out.println(words.indexOf('a'));
    }
}
