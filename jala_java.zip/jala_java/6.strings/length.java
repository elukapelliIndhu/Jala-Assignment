
public class length {

    public static void main(String[] args) {
        String name = "Hello World";
        System.out.println("3. Length of '" + name + "': " + name.length());
    }
}
