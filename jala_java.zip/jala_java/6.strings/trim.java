
public class trim {

    public static void main(String[] args) {
        String str5 = "   Java Programming   ";
        System.out.println(" Trimmed String: '" + str5.trim() + "'");
    }
}
