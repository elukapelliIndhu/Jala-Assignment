
public class convert {

    public static void main(String[] args) {
        // Converting numbers to strings with valueOf()
        int number = 123;
        String numStr = String.valueOf(number);
        System.out.println(" Number to String: " + numStr);

    }
}
