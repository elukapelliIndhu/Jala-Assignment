
public class concatination {

    public static void main(String[] args) {
        String word1 = "hello";
        String word2 = "world";
        System.out.println("given string:" + word1 + " " + word2);
    }
}
