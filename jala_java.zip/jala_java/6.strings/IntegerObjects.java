public class IntegerObjects {
    public static void main(String[] args) {
        Integer numObj = 456;
        String objStr = numObj.toString();
        System.out.println("13. Integer object to String: " + objStr);
    }
}
