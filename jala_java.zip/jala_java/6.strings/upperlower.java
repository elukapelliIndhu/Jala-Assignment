
public class upperlower {

    public static void main(String[] args) {
        //  Converting to uppercase and lowercase
        String str1 = "hello";
        System.out.println(" Uppercase: " + str1.toUpperCase());
        System.out.println("    Lowercase: " + str1.toLowerCase());
    }
}
