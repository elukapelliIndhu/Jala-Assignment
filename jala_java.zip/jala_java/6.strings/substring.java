
public class substring {

    public static void main(String[] args) {
        String name = " Hello World";
        System.out.println("substring is:" + name.substring(3));
    }
}
