
public class RelationalOperators {

    public static void main(String[] args) {
        int a = 10;
        int b = 20;

        // Less than
        System.out.println("a < b: " + (a < b));  // true

        // Less than or equal to
        System.out.println("a <= b: " + (a <= b));  // true

        // Greater than
        System.out.println("a > b: " + (a > b));  // false

        // Greater than or equal to
        System.out.println("a >= b: " + (a >= b));  // false
    }
}
