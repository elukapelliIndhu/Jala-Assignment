
public class Privatesub extends PrivateExample {

    public void accessPrivate() {
        System.out.println("Cannot access private members from subclass.");
    }
}
