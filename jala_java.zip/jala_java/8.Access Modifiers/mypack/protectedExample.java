package mypack;

public class protectedExample {

    protected String name = "Indhu";

    protected void display() {
        System.out.println("Protected method called");
    }
}
