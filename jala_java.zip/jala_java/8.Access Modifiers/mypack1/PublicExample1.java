package mypack1;

public class PublicExample1 {

    public int id = 123;

    public void show() {
        System.out.println("Public method called");
    }
}
