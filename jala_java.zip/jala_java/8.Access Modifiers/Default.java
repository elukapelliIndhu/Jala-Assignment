
public class Default {

    int number = 20;

    void greek() {
        System.out.println("hello");
    }
}
