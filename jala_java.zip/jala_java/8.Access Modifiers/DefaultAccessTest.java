
public class DefaultAccessTest {

    public static void main(String[] args) {
        Default obj = new Default();
        System.out.println("Number: " + obj.number);
        obj.greek();
    }
}
